package com.demo.myapplication;

public class Reminder {
    private String medicineName;
    private String dosage;
    private String instructions;
    private long time;

    public Reminder(String medicineName, String dosage, String instructions, long time) {
        this.medicineName = medicineName;
        this.dosage = dosage;
        this.instructions = instructions;
        this.time = time;
    }

    public String getMedicineName() {
        return medicineName;
    }

    public String getDosage() {
        return dosage;
    }

    public String getInstructions() {
        return instructions;
    }

    public long getTime() {
        return time;
    }
}
