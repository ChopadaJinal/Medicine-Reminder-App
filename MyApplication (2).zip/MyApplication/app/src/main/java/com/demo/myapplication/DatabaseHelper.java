package com.demo.myapplication;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import java.util.ArrayList;
import java.util.List;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "reminders.db";
    private static final int DATABASE_VERSION = 1;
    private static final String TABLE_REMINDERS = "reminders";
    private static final String COLUMN_ID = "id";
    private static final String COLUMN_MEDICINE_NAME = "medicine_name";
    private static final String COLUMN_DOSAGE = "dosage";
    private static final String COLUMN_INSTRUCTIONS = "instructions";
    private static final String COLUMN_TIME = "time";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String createTable = "CREATE TABLE " + TABLE_REMINDERS + " (" +
                COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COLUMN_MEDICINE_NAME + " TEXT, " +
                COLUMN_DOSAGE + " TEXT, " +
                COLUMN_INSTRUCTIONS + " TEXT, " +
                COLUMN_TIME + " INTEGER)";
        db.execSQL(createTable);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_REMINDERS);
        onCreate(db);
    }

    public void addReminder(String medicineName, String dosage, String instructions, long time) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_MEDICINE_NAME, medicineName);
        values.put(COLUMN_DOSAGE, dosage);
        values.put(COLUMN_INSTRUCTIONS, instructions);
        values.put(COLUMN_TIME, time);
        db.insert(TABLE_REMINDERS, null, values);
        db.close();
    }

    public List<Reminder> getAllReminders() {
        List<Reminder> reminders = new ArrayList<>();
        String selectQuery = "SELECT * FROM " + TABLE_REMINDERS;
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, null);

        if (cursor.moveToFirst()) {
            do {
                Reminder reminder = new Reminder(
                        cursor.getString(cursor.getColumnIndex(COLUMN_MEDICINE_NAME)),
                        cursor.getString(cursor.getColumnIndex(COLUMN_DOSAGE)),
                        cursor.getString(cursor.getColumnIndex(COLUMN_INSTRUCTIONS)),
                        cursor.getLong(cursor.getColumnIndex(COLUMN_TIME))
                );
                reminders.add(reminder);
            } while (cursor.moveToNext());
        }

        cursor.close();
        db.close();
        return reminders;
    }
}
