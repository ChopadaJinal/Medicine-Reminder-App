package com.demo.myapplication;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.app.TimePickerDialog;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.Calendar;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    EditText medicineName, dosage, instructions;
    Button setReminderButton, timePickerButton;
    TextView selectedTimeText;
    DatabaseHelper dbHelper;
    Calendar selectedTime; // Stores user-selected time
    RecyclerView remindersRecyclerView;
    ReminderAdapter reminderAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        medicineName = findViewById(R.id.medicineName);
        dosage = findViewById(R.id.dosage);
        instructions = findViewById(R.id.instructions);
        setReminderButton = findViewById(R.id.setReminderButton);
        timePickerButton = findViewById(R.id.timePickerButton);
        selectedTimeText = findViewById(R.id.selectedTimeText);
        remindersRecyclerView = findViewById(R.id.remindersRecyclerView);
        dbHelper = new DatabaseHelper(this);
        selectedTime = Calendar.getInstance();

        // Set up RecyclerView
        remindersRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        reminderAdapter = new ReminderAdapter(dbHelper.getAllReminders());
        remindersRecyclerView.setAdapter(reminderAdapter);

        // Open Time Picker
        timePickerButton.setOnClickListener(v -> openTimePicker());

        setReminderButton.setOnClickListener(v -> setReminder());
    }

    private void openTimePicker() {
        int hour = selectedTime.get(Calendar.HOUR_OF_DAY);
        int minute = selectedTime.get(Calendar.MINUTE);

        TimePickerDialog timePickerDialog = new TimePickerDialog(this, (view, selectedHour, selectedMinute) -> {
            selectedTime.set(Calendar.HOUR_OF_DAY, selectedHour);
            selectedTime.set(Calendar.MINUTE, selectedMinute);
            selectedTime.set(Calendar.SECOND, 0);
            selectedTimeText.setText(String.format("Selected Time: %02d:%02d", selectedHour, selectedMinute));
        }, hour, minute, true);

        timePickerDialog.show();
    }

    private void setReminder() {
        String medName = medicineName.getText().toString().trim();
        String medDosage = dosage.getText().toString().trim();
        String medInstructions = instructions.getText().toString().trim();

        if (medName.isEmpty() || medDosage.isEmpty() || medInstructions.isEmpty()) {
            Toast.makeText(this, "Fill all fields", Toast.LENGTH_SHORT).show();
            return;
        }

        if (selectedTimeText.getText().toString().equals("Selected Time: Not Set")) {
            Toast.makeText(this, "Please select a reminder time", Toast.LENGTH_SHORT).show();
            return;
        }

        // Save to database
        dbHelper.addReminder(medName, medDosage, medInstructions, selectedTime.getTimeInMillis());

        // Setting up the alarm
        Intent intent = new Intent(this, ReminderReceiver.class);
        intent.putExtra("medicine", medName);
        intent.putExtra("dosage", medDosage);
        intent.putExtra("instructions", medInstructions);
        PendingIntent pendingIntent = PendingIntent.getBroadcast(this, 0, intent, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        AlarmManager alarmManager = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
        alarmManager.setExact(AlarmManager.RTC_WAKEUP, selectedTime.getTimeInMillis(), pendingIntent);

        Toast.makeText(this, "Reminder Set for " + medName, Toast.LENGTH_SHORT).show();

        // Update RecyclerView
        reminderAdapter.updateReminders(dbHelper.getAllReminders());
    }
}
