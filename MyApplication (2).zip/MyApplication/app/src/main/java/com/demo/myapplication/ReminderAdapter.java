package com.demo.myapplication;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Locale;

public class ReminderAdapter extends RecyclerView.Adapter<ReminderAdapter.ReminderViewHolder> {

    private List<Reminder> reminders;

    public ReminderAdapter(List<Reminder> reminders) {
        this.reminders = reminders;
    }

    @NonNull
    @Override
    public ReminderViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.reminder_item, parent, false);
        return new ReminderViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ReminderViewHolder holder, int position) {
        Reminder reminder = reminders.get(position);
        holder.medicineName.setText(reminder.getMedicineName());
        holder.dosage.setText(reminder.getDosage());
        holder.instructions.setText(reminder.getInstructions());
        holder.time.setText(formatTime(reminder.getTime()));
    }

    @Override
    public int getItemCount() {
        return reminders.size();
    }

    public void updateReminders(List<Reminder> newReminders) {
        reminders.clear();
        reminders.addAll(newReminders);
        notifyDataSetChanged();
    }

    private String formatTime(long time) {
        SimpleDateFormat sdf = new SimpleDateFormat("HH:mm", Locale.getDefault());
        return sdf.format(time);
    }

    static class ReminderViewHolder extends RecyclerView.ViewHolder {
        TextView medicineName, dosage, instructions, time;

        public ReminderViewHolder(@NonNull View itemView) {
            super(itemView);
            medicineName = itemView.findViewById(R.id.reminderMedicineName);
            dosage = itemView.findViewById(R.id.reminderDosage);
            instructions = itemView.findViewById(R.id.reminderInstructions);
            time = itemView.findViewById(R.id.reminderTime);
        }
    }
}
